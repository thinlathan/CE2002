package registration;

import java.io.*;
//import java.nio.*;

public class ReservationStorage {
	File file;
	int updatedRCode;

	public ReservationStorage() {
		file = new File("Reservation.txt");
	}

	public void write(Reservation[] reservation, int rCode) { // rCode start from 1, update after each entry (0 is dummy)
		Reservation res;
		try {
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
			bw.write("StartingCode="+String.valueOf(rCode));
			
			for (int i = 0; i < rCode; i++) {
				bw.newLine();
				res = reservation[i];
				bw.write(res.toString());
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Reservation[] read() {
		Reservation[] dummyReservation = new Reservation[100];
		int rCode;
		String rStatus;
		int eDate;
		int eTime;
		int gID;
		String rNUmber;
		String rType;

		try {
			FileReader fr = new FileReader(file.getAbsoluteFile());
			BufferedReader br = new BufferedReader(fr);
			
			String line = br.readLine();
			updatedRCode=Integer.parseInt(line.substring(13)); //read current rCode
			if(updatedRCode!=0) {
				while (line != null) {
					line = br.readLine();
					rCode=Integer.parseInt(line.substring(6));
				
					line = br.readLine();
					rStatus=line.substring(8);
					
					line = br.readLine();
					eDate=Integer.parseInt(line.substring(6));
					
					line = br.readLine();
					eTime=Integer.parseInt(line.substring(6));
					
					line = br.readLine();
					gID=Integer.parseInt(line.substring(4));
					
					line = br.readLine();
					rNUmber=line.substring(8);
					
					line = br.readLine();
					rType=line.substring(6);
					
					dummyReservation[rCode]=new Reservation(rCode, rStatus, eDate, eTime, gID, rNUmber, rType);
					line = br.readLine();
				}
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
		return dummyReservation;
	}
	
	public int getRCode() {
		return updatedRCode;
	}
}