package registration;

public class roomServiceOrder {

		private int guestId;
		private int orderNo;
		private int dateOfOrder;
		private int timeOfOrder;
		private Item[] orderList = new Item[20];
		private String remarks;
		private String Status;
		private double RoomServiceFee;
		
		// Constructor
		public roomServiceOrder(int guest_id, int order_no) {
			orderNo = order_no;
			guestId = guest_id;
			RoomServiceFee = 0;
		}
		
		public roomServiceOrder() {
			// TODO Auto-generated constructor stub
		}

		public roomServiceOrder(int guestId,int orderNo,int dateOfOrder,int timeOfOrder,Item[] orderList,String remarks,String Status,double RoomServiceFee) {
			this.guestId= guestId;
			this.orderNo= orderNo;
			this.dateOfOrder= dateOfOrder;
			this.timeOfOrder= timeOfOrder;
			this.orderList= orderList;
			this.remarks= remarks;
			this.Status= Status;
			this.RoomServiceFee= RoomServiceFee;
		}
		public Item[] getItemList()
		{
			return orderList;
		}
		// Get order number
		public int getOrderNo() {
			return orderNo;
		}
		
		// Create new order
		public void createNewOrder(int date, int time, String remark, String status) {
			dateOfOrder = date;
			timeOfOrder = time;
			remarks = remark;
			Status = status;
		}

		// Add items to order
		public void addItem(int itemIndex, Menu menu) {
			for (int i=0; i<orderList.length; i++) {
				if (orderList[i] == null) {
					orderList[i] = menu.getOneItem(itemIndex);
					break;
				}
			}
		}
		
		// Print orderList
		public void showOrderList() {
			for (int i=0; i<orderList.length; i++) {
				if (orderList[i] != null)
					System.out.println((i+1) + ". " + orderList[i].getItemName());
			}
		}
		
		// Update remarks
		public void updateRemarks(String remark) {
			this.remarks = remark;
		}
		
		// Get remarks
		public String getRemarks() {
			return remarks;
		}
		
		// Get order status
		public String getOrderStatus() {
			return Status;
		}
		
		public int getGuestID() {
			return guestId;
		}
		
		// Update order status
		public void updateOrderStatus(String status) {
			System.out.println("Status updated from: " + Status);
			this.Status = status;
			System.out.println("to: " + Status);
		}
		
		// Print order bill and return total for one order
		public double roomServiceBill(int guest_id, int order_no) {
			System.out.println("Item(s) purchased:");
			for (int i=0; i<orderList.length; i++) {
				if (orderList[i] != null) {
					System.out.println(orderList[i].getItemName() + " ----- $" + orderList[i].getPrice());
					RoomServiceFee += orderList[i].getPrice();
				}
			}
			System.out.println("Total: $" + RoomServiceFee + "/-");
			System.out.println("Billed on " + dateOfOrder + " at " + timeOfOrder);
			
			return RoomServiceFee;
		}
		
		public String toString() 
		{
			int size=0;
			for (int i = 0;i<orderList.length;i++)
				if(orderList[i] == null) {
					size=i;
					break;
				}
			
			String items=orderList[0].toString();
			
			if(size>1) {
				for(int i=1;i<size;i++) {
					String dummy=orderList[1].toString();
					items=items.concat("\n");
					items=items.concat(dummy);
				}
			}
			
			String str = "guestId: " + guestId 
					+ "\norderNo: " + orderNo
					+ "\ndateOfOrder: " + dateOfOrder
					+ "\ntimeOfOrder: " + timeOfOrder 
					+ "\n"+items
					+ "\nremarks: " + remarks
					+ "\nStatus: " + Status
					+ "\nRoomServiceFee: " + RoomServiceFee;
			return str;
		}
} 