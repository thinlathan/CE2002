package registration;

/*Represents a menu*/
import java.util.ArrayList;

public class Menu {
	
	/**
	 * An ArrayList of items
	 */
	private ArrayList<Item> itemList = new ArrayList<Item>();
	
	/*
	 * Constructors
	 */
	public Menu() {
		//itemList.add(new Item("", "", 0.0));
	}
	
	
    /*
     * Accessors: Return one specific item in the menu
     */
	public Item getOneItem(int index)
	{
		return itemList.get(index);
	}
	
	/*
	 * return the total number of items in the menu
	 */
	public int getMenuSize()
	{
		return itemList.size();
	}
	
	/*
	 * Mutators: create and add one item into the menu
	 * @param name This item's name
	 * @param description This item's description
	 * @param price This item's price
	 */
	public void createItem(String name, String description, double price)
	{
		itemList.add(new Item(name, description, price));
	}
	
	/*
	 * Remove an item from the menu
	 */
	public void removeItem(int index)
	{
		Item item = itemList.get(index);
		itemList.remove(item);
	}
	
	/*
	 * Update an item's description and price in the menu
	 * @param index This item's index in the ArrayList
	 * @param description This item's new description
	 * @param price This item's new price
	 */
	public void updateItem(int index, String newDescription, double newPrice)
	{
		Item item = itemList.get(index);
		//item.setItemName(newName);
		item.setDescription(newDescription);
		item.setPrice(newPrice);
	}
	
	/*
	 * Overload updateItem(): update description only
	 */
	public void updateItem(int index, String newDescription)
	{
		Item item = itemList.get(index);
		//item.setItemName(newName);
		item.setDescription(newDescription);
	}
	
	/*
	 * Overload updateItem(): update price only
	 */
	public void updateItem(int index, double newPrice)
	{
		Item item = itemList.get(index);
		item.setPrice(newPrice);
	}

	
	/*
	 * Print the menu (print all items)
	 */
	public String toString() {
		String str = "";
		str += "MENU: \n" + "--------------------------------------------------\n";
		//str += getAllItems() + "\n";
		for(int i = 0; i < itemList.size(); i++) {
			str += "-------------------------------------------------- \n";
			Item item = itemList.get(i);
			str += (i+1) + " " + item.toString() + "\n\n";
		}
		return str;
	}
	
}