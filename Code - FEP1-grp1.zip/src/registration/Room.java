package registration;

import java.util.Scanner;

public class Room {
	// room identifier
	private int guestID;
	private String roomNumber;
	private String roomType;
	private String roomStatus;
	// room details
	private String bedType;
	private double rateNormal;
	private double rateWeekend;
	private boolean hasWIFI;
	private String facing;
	private boolean smoking;
	private boolean hasBalcony;
	private boolean hasPool;

	// occupation
	private boolean isEmpty;
	// room numbers

	public static String[] singleRoomNo = new String[] { "01-01", "01-03", "01-05", "02-02", "02-04", "02-06", "03-01",
			"03-03", "03-05", "03-07", "04-02", "04-06", "04-07", "05-01", "05-03" };
	public static String[] doubleRoomNo = new String[] { "01-02", "01-04", "01-06", "01-07", "02-01", "02-03", "02-05",
			"02-07", "03-02", "03-04", "03-06", "04-01", "04-03", "04-04", "04-05", "05-02", "05-04", "05-05", "05-06",
			"05-07", "06-01", "06-02", "06-03", "06-04", "06-05" };
	public static String[] deluxeRoomNo = new String[] { "06-06", "06-07", "07-01", "07-02", "07-03" };
	public static String[] VIPSuiteNo = new String[] { "07-04", "07-05", "07-06" };

	public Room(int guestID, String roomNumber, String rType, String roomStatus, String bedType, double rateNormal,
			double rateWeekend, boolean hasWIFI, String facing, boolean smoking, boolean hasBalcony, boolean hasPool,
			boolean isEmpty) {
		
		this.guestID = guestID;
		this.roomNumber = roomNumber;
		this.roomType = rType;
		this.roomStatus = roomStatus;
		this.bedType = bedType;
		this.rateNormal = rateNormal;
		this.rateWeekend = rateWeekend;
		this.hasWIFI = hasWIFI;
		this.facing = facing;
		this.smoking = smoking;
		this.hasBalcony = hasBalcony;
		this.hasPool = hasPool;
		this.isEmpty=isEmpty;
	}

	public Room(String rType, String bedType, double rateNormal, double rateWeekend, boolean hasWIFI, String facing,
			boolean smoking, boolean hasBalcony, boolean hasPool) {
		this.roomType = rType;
		this.isEmpty = true;
		this.roomStatus = "Vacant";
		this.bedType = bedType;
		this.rateNormal = rateNormal;
		this.rateWeekend = rateWeekend;
		this.hasWIFI = hasWIFI;
		this.facing = facing;
		this.smoking = smoking;
		this.hasBalcony = hasBalcony;
		this.hasPool = hasPool;
	}

	// methods
	// SET ROOM NUMBER
	public void setRoomNumberSingle(int i) {
		this.roomNumber = singleRoomNo[i];
	}

	public void setRoomNumberDouble(int i) {
		this.roomNumber = doubleRoomNo[i];
	}

	public void setRoomNumberDeluxe(int i) {
		this.roomNumber = deluxeRoomNo[i];
	}

	public void setRoomNumberVIP(int i) {
		this.roomNumber = VIPSuiteNo[i];
	}

	// GET ROOM NUMBER
	public String getRoomNumber() {
		return this.roomNumber;
	}

	// add guest to room
	// assign
	public void assignRoom(int guestID, String roomStatus) {
		this.guestID = guestID;
		this.isEmpty = false;
		this.roomStatus = roomStatus;
	}

	// unassign
	public void unAssignRoom() {
		this.guestID = -1;
		this.isEmpty = true;
		this.roomStatus = "Vacant";
	}

	// STATUS
	// GET
	public String getRoomStatus() {
		return this.roomStatus;
	}

	// SET
	public void setStatus(String roomStatus) {
		this.roomStatus = roomStatus;
	}

	// RATE
	// if it's the weekend, return weekend rate and vice versa
	public double getRate(boolean weekend) {
		if (weekend == true) {
			return this.rateWeekend;
		} else {
			return this.rateNormal;
		}
	}

	// EMPTY
	public boolean occupancy() {
		return this.isEmpty;
	}

	// ROOM DETAILS
	// GET
	public String getBedType() {
		return this.bedType;
	}

	public String getFacing() {
		return this.facing;
	}

	public boolean getBalcony() {
		return this.hasBalcony;
	}

	public boolean getPool() {
		return this.hasPool;
	}

	public boolean getsmoking() {
		return this.smoking;
	}

	public boolean getWIFI() {
		return this.hasWIFI;
	}

	// UPDATE room details
	public void setBedType(String bedType) {
		this.bedType = bedType;
	}

	public void setNormalRate(double rateNormal) {
		this.rateNormal = rateNormal;
	}

	public void setWeekendRate(double rateWeekend) {
		this.rateWeekend = rateWeekend;
	}

	public void setFacing(String facing) {
		this.facing = facing;
	}

	public void setBalcony(boolean hasBalcony) {
		this.hasBalcony = hasBalcony;
	}

	public void setPool(boolean hasPool) {
		this.hasPool = hasPool;
	}

	public void setSmoking(boolean smoking) {
		this.smoking = smoking;
	}

	public void setWIFI(boolean hasWIFI) {
		this.hasWIFI = hasWIFI;
	}

	/// Update room details function
	public void setRoomDetails() {
		Scanner sc = new Scanner(System.in);
		int choice;
		do {
			System.out.println("Choose the details you want to set: ");
			System.out.println("1) Bed Type");
			System.out.println("2) Normal day rate");
			System.out.println("3) Weekend day rate");
			System.out.println("4) Facing details");
			System.out.println("5) Balcony details");
			System.out.println("6) Pool details");
			System.out.println("7) Smoking restriction details");
			System.out.println("8) WIFI details");
			System.out.println("9) Update room status details");
			System.out.println("10) Quit.");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter bed type: ");
				setBedType(sc.next());
				break;
			case 2:
				System.out.println("Enter normal day rate: ");
				setNormalRate(sc.nextDouble());
				break;
			case 3:
				System.out.println("Enter weekend day rate: ");
				setWeekendRate(sc.nextDouble());
				break;
			case 4:
				System.out.println("Enter facing details: ");
				setFacing(sc.next());
				break;
			case 5:
				System.out.println("Enter balcony details: ");
				setBalcony(sc.nextBoolean());
				break;
			case 6:
				System.out.println("Enter pool details: ");
				setPool(sc.nextBoolean());
				break;
			case 7:
				System.out.println("Enter smoking details: ");
				setSmoking(sc.nextBoolean());
				break;
			case 8:
				System.out.println("Enter WIFI details: ");
				setWIFI(sc.nextBoolean());
				break;
			case 9:
				System.out.println("Current status of room: " + getRoomStatus());
				int sub_choice;
				do {
					System.out.println("Enter wanted status: ");
					System.out.println("1) Reserved");
					System.out.println("2) Vacant");
					System.out.println("3) Occupied");
					System.out.println("4) Under Maintenance");
					System.out.println("5) Quit");
					sub_choice = sc.nextInt();
					sc.nextLine();
					switch (sub_choice) {
					case 1:
						if (getRoomStatus().equals("Reserved")) {
							System.out.println("Room is already Reserved");
							break;
						} else if (getRoomStatus().equals("Vacant")) {
							System.out.println("Please make a reservation to room " + this.roomNumber
									+ " to change room status to Reserved");
							break;
						}
						System.out.println("Cannot make reservation. Room is " + getRoomStatus());
						break;
					case 2:
						if (getRoomStatus().equals("Vacant")) {
							System.out.println("Room is already Vacant");
							break;
						} else if (getRoomStatus().equals("Under Maintenance")) {
							setStatus("Vacant");
							System.out.println("Room status has been set to Vacant");
							this.isEmpty = true;
							break;
						}
						System.out.println("Please Check-out guest from room " + this.roomNumber
								+ " to change room status to Vacant");
						break;
					case 3:
						if (getRoomStatus().equals("Occupied")) {
							System.out.println("Room is already Occupied");
							break;
						} else if (getRoomStatus().equals("Under Maintenance")) {
							System.out.println("Cannot make change to status. Room is " + getRoomStatus());
							break;
						}
						System.out.println(
								"Please check in to room " + this.roomNumber + " to change room status to Occupied");
						break;

					case 4:
						if (getRoomStatus().equals("Under Maintenance")) {
							System.out.println("Room is already under maintenance");
							break;
						} else if (getRoomStatus().equals("Vacant")) {
							setStatus("Under Maintenance");
							this.isEmpty = false;
							System.out.println("Room status has been set to Under Maintenance");
							break;
						}
						System.out.println(
								"Room is Occupied or Reserved. Please remove Reservation or Check-out guest to put room under maintenance");
						break;
					case 5:
						break;
					default:
						System.out.println("Please enter appropriate number (1-5)");
						break;
					}
				} while (sub_choice < 5);
			case 10:
				System.out.println("Quitting...");
				break;
			default:
				System.out.println("Enter number from 1-10");
				break;
			}
		} while (choice < 10);
	}

	public String toString() {
		return "guestID:" + guestID + "\nroomNumber:" + roomNumber + "\nroomType:" + roomType + "\nroomStatus:"
				+ roomStatus + "\nbedType:" + bedType + "\nrateNormal:" + rateNormal + "\nrateWeekend:" + rateWeekend
				+ "\nhasWIFI:" + hasWIFI + "\nfacing:" + facing + "\nsmoking:" + smoking + "\nhasBalcony:" + hasBalcony
				+ "\nhasPool:" + hasPool + "\nisEmpty:" + isEmpty;
	}
}