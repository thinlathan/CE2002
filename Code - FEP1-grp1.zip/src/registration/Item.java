package registration;

/* Represents a item in the menu of room service*/


public class Item {
	
	/** 
	 * The name of an item
	 */
	private String itemName;
	/** 
	 * The description of an item
	 */
	private String description;
	/** 
	 * The price of an item
	 */
	private double price;
	
	/**
	 * Constructors
	 * Create an item with
	 * @param itemName This item's name
	 * @param description This item's description
	 * @param price This item's price
	 */
	public Item(String itemName, String description, double price)
	{
		this.itemName = itemName;
		this.description = description;
		this.price = price;
	}
	
	public void UpdateItem(String itemName, String description, double price)
	{
		this.itemName = itemName;
		this.description = description;
		this.price = price;
	}
	

	/** 
	 * Accessors
	 * Get the name, description, or price of this item.
	 * @return this item's name
	 * @return this item's description
	 * @return this item's price
	 */
	
	public String getItemName()
	{
		return itemName;
	}
	
	public String getDescription()
	{
		return description;
	}
	
	public double getPrice()
	{
		return price;
	}
	
	/**
	 * Mutators
	 * Change the name, description, or price of this item
	 * @param name This item's new name
	 * @param description This item's new description
	 * @param price This item's new price
	 */
	public void setItemName(String name)
	{
		itemName = name;
	}
	
	public void setDescription(String description)
	{
		this.description = description;
	}
	
	public void setPrice(double price)
	{
		this.price = price;
	}
	
	
	/*
	 * toString(non-Javadoc)
	 * Print this item out
	 */
	public String toString() 
	{
		String str = "Name: " + itemName 
				+ "\nDescription: " + description
				+ "\nPrice: " + price;
		return str;
	}
}