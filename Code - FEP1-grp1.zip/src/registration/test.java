package registration;

import java.io.Serializable;
import java.text.ParseException;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public class test implements Serializable {
	private static int date;
	private static int time;
	private static int choice;

	// Reservation and Check-in
	private static Reservation[] reservation = new Reservation[100];
	private static Check_in[] checkIn = new Check_in[100];
	private static int rCode = 0;
	private static int cCode = 1;
	private static int guestID = 0;
	private static int order_no = 0;

	// roomManager and guestDb
	private static roomMnger roomManager = new roomMnger();
	private static GuestDB gList = new GuestDB();
	private static CheckOutManager checkOutManager = new CheckOutManager();
	private static Menu menu = new Menu();
	private static ArrayList<roomServiceOrder> orderList = new ArrayList<roomServiceOrder>();

	// Storage
	private static MenuStorage menuStorage = new MenuStorage();
	private static ReservationStorage reservationStorage = new ReservationStorage();
	private static CheckInStorage checkInStorage = new CheckInStorage();
	private static GuestDBStorage guestDBStorage = new GuestDBStorage();
	private static RoomServiceOrderStorage roomServiceOrderStorage = new RoomServiceOrderStorage();
	private static RoomMngerStorage roomMngerStorage = new RoomMngerStorage();

	public static void main(String[] args) throws ParseException {
		Scanner sc = new Scanner(System.in);
		int choice;
		int sub_choice;
		String target_roomType;
		String target_roomNumber;
		int target_rCode;
		int target_guestID;
		String target_guestName;
		Guest target_guest;
		String status;
		Room target_room;
		boolean check = false;
		
		do {
			setDateAndTime();
			
			checkExpiryForReservations();
			System.out.println("Enter your choice");
			System.out.println("0. Load previous datas");
			System.out.println("1. Creating a reservation");
			System.out.println("2. Updating a reservation");
			System.out.println("3. Creating a Room Check-in (check-in and reservation)");
			System.out.println("4. Update Guest");
			System.out.println("5. Search Guest");
			System.out.println("6. Update room details"); 
			System.out.println("7. Create room service order"); // To be done
			System.out.println("8. Create/Update/Remove room service menu item"); 
			System.out.println("9. Check out"); // To be done. Need to add room service order
			System.out.println("10. Print room statistic report");
			System.out.println("11. Print all reservations");
			System.out.println("12. Save and quit");
			choice = sc.nextInt();
			sc.nextLine();
			switch (choice) {
			case 0:
				//orderList = roomServiceOrderStorage.read();
				//order_no=roomServiceOrderStorage.getOrderNo();
				roomManager=roomMngerStorage.read();
				menu=menuStorage.read();
				reservation=reservationStorage.read();
				rCode=reservationStorage.getRCode();
				checkIn=checkInStorage.read();
				cCode=checkInStorage.getcCode();
				gList=guestDBStorage.read();
				guestID=guestDBStorage.getUpdatedGuestID();
				break;
			case 1: // Create and print reservation + Create guest
				guestID++;
				gList.createGuest();
				roomManager.printRoomTypeOccupancyReport();
				do {
					System.out.println("Enter your desired room type (Single/Double/Deluxe/VIP)");
					target_roomType = sc.nextLine();
					System.out.println("Enter your desired room number");
					target_roomNumber = sc.nextLine();
				} while (!roomManager.checkRoomType(target_roomType, target_roomNumber));
				roomManager.assign(guestID, "Reserved", target_roomNumber, target_roomType);
				reservation[rCode] = new Reservation(rCode, guestID, target_roomNumber, target_roomType);
				rCode++;
				break;
			case 2: // update reservation including guest detail
				System.out.println("Enter your reservation code");
				target_rCode = sc.nextInt();
				sc.nextLine();
				if (target_rCode > rCode - 1)
					System.out.println("No such reservation!");
				else {
					sub_choice = reservation[target_rCode].checkReservationStatus();
					if (sub_choice != 1) {
						do {
							System.out.println("Which details of reservation you would like to change?");
							System.out.println("1. About guest details");
							System.out.println("2. About check in date and time");
							System.out.println("3. Quit");
							sub_choice = sc.nextInt();
							sc.nextLine();
							switch (sub_choice) {
							case 1:
								if (gList.getCount() > 0) {
									System.out.println("Enter the name of guest to be updated:");
									String search = sc.nextLine();
									Guest Search = gList.searchGuest(gList, search);
									if (Search.getEmpty())
										System.out.println("Guest does not exist in the database.");
									else {
										gList.searchGuest(gList, search).updateGuest();
									}
								} else
									System.out.println("No guest resides in this hotel. Create a new guest to update.");
								break;
							case 2:
								reservation[target_rCode].updateReservation();
								break;
							case 3:
								break;
							default:
								System.out.println("Wrong input!");
							}
						} while (sub_choice != 3);
					} else
						System.out.println("You have been checked in already!");
				}
				break;
			case 3: // Check-in
				do {
					System.out.println("Do you have a reservation?");
					System.out.println("1. Yes, I had a reservation.");
					System.out.println("2. No, I am a walk-in guest");
					System.out.println("3. Quit");
					sub_choice = sc.nextInt();
					sc.nextLine();
					switch (sub_choice) {
					case 1:// by reservation
						System.out.println("Enter your reservation code");
						target_rCode = sc.nextInt();
						if (target_rCode > rCode - 1)
							System.out.println("No such reservation!");
						else {
							status = reservation[target_rCode].getReservationStatus();
							if (status.equals("Confirmed") == true) {
								reservation[target_rCode].printReservationAcknowledgementReceipt();
								System.out.println("Is it valid? (true/false)");
								check = sc.nextBoolean();
								if (check == true) {
									target_roomNumber = reservation[target_rCode].getRoomNumber();
									target_roomType = reservation[target_rCode].getRoomType();
									target_guestID = reservation[target_rCode].getGuestID();
									reservation[target_rCode].checkInReservation();
									roomManager.assign(target_guestID, "Occupied", target_roomNumber, target_roomType);
									checkIn[cCode] = new Check_in(cCode,date, time, target_guestID, target_roomNumber,target_roomType);
									cCode++;		
								} else
									System.out.println("Your reservation is not valid");
							} else if (status.equals("Expired"))
								System.out.println("Your reservation has expired");

							else if (status.equals("Checked_In"))
								System.out.println("Your reservation has expired");
						}
						break;
					case 2:// by walk-in
						guestID++;
						gList.createGuest();
						roomManager.printRoomTypeOccupancyReport();
						do {
							System.out.println("Enter your desired room type (Single/Double/Deluxe/VIP)");
							target_roomType = sc.nextLine();
							System.out.println("Enter your desired room number");
							target_roomNumber = sc.nextLine();
						} while (!roomManager.checkRoomType(target_roomType, target_roomNumber));
						roomManager.assign(guestID, "Occupied", target_roomNumber, target_roomType);
						checkIn[cCode] = new Check_in(cCode,date, time, guestID, target_roomNumber,target_roomType);
						checkIn[cCode].printReceipt();
						cCode++;
						break;
					case 3:
						break;
					default:
						System.out.println("Wrong input, try again!");
					}
				} while ((sub_choice != 1)&(sub_choice != 2));

				break;
			case 4:// Update guest. Used in case 2 also
				if (gList.getCount() > 0) {
					System.out.println("Enter the name of guest to be updated:");
					String search = sc.nextLine();
					Guest Search = gList.searchGuest(gList, search);
					if (Search.getEmpty())
						System.out.println("Guest does not exist in the database.");
					else
						gList.searchGuest(gList, search).updateGuest();
				} else
					System.out.println("No guest resides in this hotel. Create a new guest to update.");
				break;
			case 5:// Search guest
				if (gList.getCount() <= 0)
					System.out.println("No guest resides in this hotel. Create a new guest in order to search");
				else {
					System.out.println("Enter name of guest to be searched: ");
					String search = sc.nextLine();
					Guest Search = gList.searchGuest(gList, search);
					if (!Search.getEmpty())
						gList.searchGuest(gList, search).print();
					else
						System.out.println("Guest does not exist in the database.");
				}
				break;
			case 6: // Update room details
				do {
					System.out.println("Enter your desired room type (Single/Double/Deluxe/VIP)");
					target_roomType = sc.nextLine();
					System.out.println("Enter your desired room number");
					target_roomNumber = sc.nextLine();
				} while (!roomManager.checkRoomType(target_roomType, target_roomNumber));
				target_room = roomManager.getRoom(target_roomType, target_roomNumber);
				target_room.setRoomDetails();
				break;
			case 7: // Create room service order
				int guest_id;
				System.out.println("Room Service Ordering System");
				do {
					System.out.print("Enter guest ID: ");
					guest_id = sc.nextInt();
					if(guest_id>guestID)
						System.out.println("No such guestID, try again");
				}while(guest_id>guestID);
				
				System.out.println("Choose your option");
				System.out.println("1. Create new order");				
				System.out.println("2. Update order status");
				System.out.println("3. Print bill");
				sc.nextLine();
				sub_choice=sc.nextInt();
				switch(sub_choice)
				{
				case 1:
					roomServiceOrder rso;
					orderList.add(new roomServiceOrder(guest_id, order_no));
					rso=orderList.get(order_no);
					System.out.println("Note: Your order number is "+order_no);
					rso.createNewOrder(date, time, "NIL", "Creating order");
					String order_status= rso.getOrderStatus();
					System.out.println("Current status: " + order_status);
					System.out.println("Do you want to add an item?");
					sc.nextLine();
					char addAnother = sc.nextLine().charAt(0);
					while(!(addAnother =='n' || addAnother == 'N')) {
						System.out.println(menu.toString()); // Print menu
						System.out.print("Enter item number to add to order: ");
						int item_no = sc.nextInt() - 1;
						if (item_no > menu.getMenuSize()) {
							System.out.println("#menu size is " + menu.getMenuSize());
							System.out.println("Item does not exist. Please try again");
						}
						else {
							rso.addItem(item_no, menu);
							System.out.print("Add another item? y/n ");
							addAnother = sc.next().charAt(0);
						}
					}
					System.out.println("Any remarks? ");
					sc.nextLine();
					String remarks = sc.nextLine();
					rso.updateRemarks(remarks);
					System.out.print("Thank you, your order has been sent.\n"
							+ "Order summary:\n");
					rso.showOrderList();
					order_no++;
					
					break;
				case 2:
					int target_order_no;
					int target_status;
					do {
						System.out.print("Enter order number: ");
						target_order_no = sc.nextInt();
						if(target_order_no>order_no)
							System.out.println("Please enter a valid order number");
					}while(target_order_no>order_no);
					
					rso=orderList.get(target_order_no);
					System.out.println("To what status to be updated?");
					System.out.println("1. Processing order");
					System.out.println("2. Delivered");
					target_status=sc.nextInt();
					switch(target_status) {
					case 1:
						rso.updateOrderStatus("Processing order");
						break;
					case 2: 
						rso.updateOrderStatus("Delivered");
						break;
					}
					break;
				case 3:
					do {
						System.out.print("Enter order number: ");
						target_order_no = sc.nextInt();
						if(target_order_no>order_no)
							System.out.println("Please enter a valid order number");
					}while(target_order_no>order_no);
					rso=orderList.get(target_order_no);
					rso.roomServiceBill(guest_id, order_no);
					break;
				}
				break;
			case 8: // Create/Update/Remove room service menu item
				System.out.println("Welcome to the Room Service Management System!");
				String name;
				String description;
				double price;

				char choice1;
				do {
					System.out.println("Do you need to create/update/remove room service menu items? y/n");

					choice1 = sc.next().charAt(0);
					while (!(choice1 == 'y' || choice1 == 'Y' || choice1 == 'n' || choice1 == 'N')) {
						System.out.println("Invaild input. Please enter again.");
						choice1 = sc.next().charAt(0);
					}

					if (choice1 == 'y') {
						System.out.println("1. Create an item in the menu.");
						System.out.println("2. Update an item in the menu.");
						System.out.println("3. Remove an item in the menu.");
						System.out.println("Please enter the number of your choice.");
						int choice2 = sc.nextInt();
						sc.nextLine(); // Read the leftover new line
						while (choice2 != 1 && choice2 != 2 && choice2 != 3) {
							System.out.println("Invaild input. Please enter again.");
							choice2 = sc.nextInt();
						}
						switch (choice2) {
						case 1:
							System.out.println("Please enter the name of item you want to create: ");
							name = sc.nextLine();
							System.out.println("Please enter the new description: ");
							description = sc.nextLine();
							System.out.println("Please enter the new price: ");
							price = sc.nextDouble();
							menu.createItem(name, description, price);
							System.out.println("Item Created!");
							break;
						case 2:
							System.out.println(menu.toString()); // Print the original menu first
							System.out.println("Please enter the index number of item you want to update: ");
							int i = sc.nextInt() - 1;
							while (i >= menu.getMenuSize()) {
								System.out.println("Exceed the range. Please enter again.");
								i = sc.nextInt() - 1;
							}
							System.out.println(
									"Do you want to modify the description or price or both? Please enter the index number.");
							System.out.println("1. Description only.");
							System.out.println("2. Price only.");
							System.out.println("3. Both description and price.");
							int choice3 = sc.nextInt();
							sc.nextLine();
							while (!(choice3 == 1 || choice3 == 2 || choice3 == 3)) {
								System.out.println("Invaild input. Please enter again.");
								choice3 = sc.nextInt();
							}
							if (choice3 == 1) {
								System.out.println("Please enter the new description: ");
								description = sc.nextLine();
								menu.updateItem(i, description);
							} else if (choice3 == 2) {
								System.out.println("Please enter the new price: ");
								price = sc.nextDouble();
								menu.updateItem(i, price);
							} else {
								System.out.println("Please enter the new description: ");
								description = sc.nextLine();
								System.out.println("Please enter the new price: ");
								price = sc.nextDouble();
								menu.updateItem(i, description, price);
							}
							System.out.println("Item Updated!");
							System.out.println("New menu: ");
							System.out.println(menu.toString()); // Print the new menu
							break;
						case 3:
							System.out.println(menu.toString()); // Print the original menu first
							System.out.println("Please enter the index of the item you want to delete: ");
							int j = sc.nextInt() - 1;
							while (j >= menu.getMenuSize()) {
								System.out.println("Exceed the range. Please enter again.");
								j = sc.nextInt() - 1;
							}
							menu.removeItem(j);
							System.out.println("Item Removed!");
							System.out.println("New menu: ");
							System.out.println(menu.toString()); // Print the new menu
							break;
						default:
							System.out.println("Invalid choice.\n");
						}
						System.out.println("\n");
					}
				} while (choice1 == 'y');

				// Display the menu
				System.out.println("Do you want to show the full menu? y/n");
				char choice4 = sc.next().charAt(0);
				while (!(choice4 == 'y' || choice4 == 'n' || choice4 == 'Y' || choice4 == 'N')) {
					System.out.println("Invaild input. Please enter again.");
					choice4 = sc.next().charAt(0);
				}
				if (choice4 == 'y' || choice4 == 'Y')
					System.out.println(menu.toString());
				break;
			case 9: // Checkout
				 ArrayList<roomServiceOrder> target_order=new ArrayList<roomServiceOrder>();
                 roomServiceOrder tempOrder;
                 int tempGuestId;
                 int i;
                 int target_totalOrder;
                 System.out.println("Do you wish to check out?");
                 String input = sc.nextLine();
                 if (input.equals("Yes") || input.equals("yes") || input.equals("y")){
                     System.out.println("Enter guest name: ");
                     target_guestName = sc.nextLine();
                     target_guest=gList.searchGuest(gList, target_guestName);
                     target_guestID=target_guest.getGuestID();
                     for(i=1;i<cCode;i++) {          
                         if(checkIn[i].getGuestID()==target_guestID) {
                             break;
                             }
                         }                     
                     target_roomNumber=checkIn[i].getRoomNumber();
                     target_roomType=checkIn[i].getRoomType();
                     target_room=roomManager.getRoom(target_roomType, target_roomNumber);
                     target_guest=gList.getGuestElement(target_guestID-1);
                     
                     //roomServiceOrder
                     for(int k=0;k<orderList.size();k++) {
                         tempOrder=orderList.get(k);
                         tempGuestId=tempOrder.getGuestID();
                         if (tempGuestId==target_guestID)
                             target_order.add(tempOrder);
                     }
                     target_totalOrder = target_order.size();
                     roomManager.unAssign(target_roomNumber,target_roomType);
                     checkOutManager.checkOut(checkIn[i],target_guest,target_room, target_totalOrder,target_order);
                 }
                 break;
			case 10:
				System.out.println("Do you want print...");
				System.out.println("1. Room Type");
				System.out.println("2. Room Status");
				sub_choice = sc.nextInt();
				switch (sub_choice) {
				case 1:
					roomManager.printRoomTypeOccupancyReport();
					break;
				case 2:
					roomManager.printStatusReport();
					break;
				default:
					System.out.println("No such option");
				}
				break;
			case 11:
				for(i=0;i<rCode;i++) {
					if(reservation[i].checkReservationStatus()==0)
						reservation[i].printReservationAcknowledgementReceipt();
				}
				break;
			case 12:
				guestDBStorage.write(gList);
				menuStorage.write(menu);
				roomServiceOrderStorage.write(orderList,order_no);
				checkInStorage.write(checkIn, cCode);
				reservationStorage.write(reservation,rCode);
				roomMngerStorage.write(roomManager);
				break;
			default:
				System.out.println("Invalid entry. Enter choice again");
			}
		}while(choice!=12);

	}

	private static void checkExpiryForReservations() {
		String stat;
		Reservation res;
		if (rCode != 0) // Check reservation expiry everytime
			for (int i = 0; i < rCode; i++)
				reservation[i].checkExpiry();
		for (int i = 0; i < rCode; i++) {
			res=reservation[i];
			stat=res.getReservationStatus();
			if(stat.equals("Expired")) {
				String roomNum=res.getRoomNumber();
				String roomTyp = res.getRoomType(); 
				roomManager.unAssign(roomNum, roomTyp);
			}
		}
	}

	private static void setDateAndTime() {
		String dateAndTime;
		String temp_date;
		String temp_time;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd HHmmss");
		LocalDateTime now = LocalDateTime.now();
		dateAndTime = dtf.format(now);

		String[] splited = dateAndTime.split(" ");
		temp_date = splited[0];
		temp_time = splited[1];

		date = Integer.parseInt(temp_date);
		time = Integer.parseInt(temp_time);
	}

	public static int getDate() {
		return date;
	}

	public static int getTime() {
		return time;
	}

}
