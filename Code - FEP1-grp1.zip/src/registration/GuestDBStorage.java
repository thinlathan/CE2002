package registration;

import java.io.*;
//import java.nio.*;

public class GuestDBStorage {
	File file;
	int updatedGuestID;

	public GuestDBStorage() {
		file = new File("Guest.txt");
	}

	public void write(GuestDB guestDB) { // guestID start from 0, update before each entry but maxID start
														// from 1?
		Guest[] gList=guestDB.getGuestList();
		Guest guest;
		try {
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);

			bw.write("StartingCode=" + String.valueOf(guestDB.getCount()));

			for (int i = 0; i < guestDB.getCount(); i++) {
				bw.newLine();
				guest = gList[i];
				bw.write(guest.toString());
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public GuestDB read() {
		GuestDB dummyGuestDB = new GuestDB();

		int guest_ID;
		String name;
		String ccNo;
		String address;
		String country;
		String nationality;
		String gender;
		String identity;
		String contact;
		int numChildren;
		int numAdults;
		int max_ID;
		int totalGuest;
		Boolean check;
		Boolean empty;

		try {
			FileReader fr = new FileReader(file.getAbsoluteFile());
			BufferedReader br = new BufferedReader(fr);

			String line = br.readLine();
			updatedGuestID = Integer.parseInt(line.substring(13)); // read current cCode
			if (updatedGuestID >0) {
				while (line != null) {
					line = br.readLine();
					guest_ID = Integer.parseInt(line.substring(8));

					line = br.readLine();
					name = line.substring(5);

					line = br.readLine();
					ccNo = line.substring(5);
					
					line = br.readLine();
					address = line.substring(8);
					
					line = br.readLine();
					country = line.substring(8);

					line = br.readLine();
					nationality = line.substring(12);

					line = br.readLine();
					gender = line.substring(7);
					
					line = br.readLine();
					identity = line.substring(9);
					
					line = br.readLine();
					contact = line.substring(8);
					
					line = br.readLine();
					numChildren = Integer.parseInt(line.substring(12));
					
					line = br.readLine();
					numAdults = Integer.parseInt(line.substring(10));
					
					line = br.readLine();
					max_ID = Integer.parseInt(line.substring(7));
					
					line = br.readLine();
					totalGuest = Integer.parseInt(line.substring(11));
					
					line = br.readLine();
					check = Boolean.parseBoolean(line.substring(6));
					
					line = br.readLine();
					empty = Boolean.parseBoolean(line.substring(6));
					
					dummyGuestDB.updateGuest(guest_ID, name, ccNo, address, country, nationality, gender, identity, contact, numChildren, numAdults, max_ID, totalGuest, check, empty);
									
					line = br.readLine();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dummyGuestDB;
	}

	public int getUpdatedGuestID() {
		return updatedGuestID;
	}
}