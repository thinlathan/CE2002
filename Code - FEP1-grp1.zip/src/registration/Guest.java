package registration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Date;
import java.util.Scanner;

public class Guest {
	Scanner sc = new Scanner(System.in);
	private int guest_ID;
	private String name;
	private String ccNo;
	private String address;
	private String country;
	private String nationality;
	private String gender;
	private String identity;
	private String contact;
	private static int numChildren;
	private static int numAdults;
	private static int max_ID = 1;
	private static int totalGuest = 0;
	private Boolean check;
	private Boolean empty;

	public Guest() {
		empty = true;
	}

	public Guest(int guest_ID, String name, String ccNo, String address, String country, String nationality,
			String gender, String identity, String contact, int numChildren, int numAdults, int max_ID, int totalGuest,
			Boolean check, Boolean empty) {
		this.guest_ID = guest_ID;
		this.name = name;
		this.ccNo = ccNo;
		this.address = address;
		this.country = country;
		this.nationality = nationality;
		this.gender = gender;
		this.identity = identity;
		this.contact = contact;
		this.numChildren = numChildren;
		this.numAdults = numAdults;
		this.max_ID = max_ID;
		this.totalGuest = totalGuest;
		this.check = check;
		this.empty = empty;
	}

	public Guest(Boolean confirm) {
		empty = false;
		check = false;
		totalGuest += 1;
		System.out.println("Enter Guest information (guestID:" + max_ID + ")");
		guest_ID = max_ID;

		System.out.println("Enter name of Guest: ");
		name = sc.nextLine();
		System.out.println("Guest Name has been noted");

		System.out.println("Enter numer of adults: ");
		numAdults = sc.nextInt();
		System.out.println("Number of adults has been noted");

		System.out.println("Enter numer of children: ");
		numChildren = sc.nextInt();
		sc.nextLine();
		System.out.println("Number of children has been noted");

		System.out.println("Please enter credit card number");
		ccNo = sc.nextLine();
		System.out.println("Credit Card No has been noted");

		System.out.println("Please enter address");
		address = sc.nextLine();
		System.out.println("Address has been noted down.");

		System.out.println("Please enter your country: ");
		country = sc.nextLine();
		System.out.println("Country has been noted.");

		System.out.println("Please enter nationality.");
		nationality = sc.nextLine();
		System.out.println("Nationality has been noted down");

		do {
			System.out.println("Please enter your gender");
			gender = sc.nextLine();
			if (gender.equals("male") || gender.equals("M") || gender.equals("Male") || gender.equals("m")) {
				gender = "Male";
				check = true;
			} else if (gender.equals("Female") || gender.equals("F") || gender.equals("f") || gender.equals("female")) {
				gender = "Female";
				check = true;
			} else {
				System.out.println("Enter invalid entry. Try again");
				check = false;
			}

		} while (!check);

		System.out.println("Enter the guest identity: (1)Passport Number (2)License Number");
		int choice = sc.nextInt();
		sc.nextLine();
		do {
			switch (choice) {
			case 1:
				System.out.println("Please enter passport number");
				identity = sc.nextLine();
				check = true;
				break;
			case 2:
				System.out.println("Please enter license number");
				identity = sc.nextLine();
				check = true;
				break;
			default:
				System.out.println("Invalid entry. Please try again");
				check = false;
				break;
			}
		} while (check = false);
		System.out.println("Guest identity has been saved.");
		System.out.println("Enter contact number: ");
		contact = sc.nextLine();
		System.out.println("Guest contact number has been saved.");
		max_ID += 1;
	}

	public void updateGuest() {
		System.out.print("Current Guest Information:");
		print();
		int choice;
		do {
			System.out.println("Choose an attribute to be updated for Guest. (Press the corresponding number)");
			System.out.println("1. Update Guest Name");
			System.out.println("2. Update Guest Identity");
			System.out.println("3. Update Guest Credit Card Number");
			System.out.println("4. Update Guest Contact Number");
			System.out.println("5. Update Guest Address");
			System.out.println("6. Exit");
			choice = sc.nextInt();
			sc.nextLine();
			switch (choice) {
			case 1:
				System.out.println("Enter updated guest name");
				this.name = sc.nextLine();
				System.out.println("Guest name is updated");
				break;
			case 2:
				System.out.println("Enter updated guest identity (1) Passport (2) License");
				int sel = sc.nextInt();
				sc.nextLine();
				do {
					switch (sel) {
					case 1:
						System.out.println("Enter updated passport number.");
						this.identity = sc.nextLine();
						System.out.println("Passport number has been successfully updated.");
						check = true;
						break;
					case 2:
						System.out.println("Enter updated license number.");
						this.identity = sc.nextLine();
						System.out.println("License number has been successfully updated");
						check = true;
					default:
						System.out.println("Invalid entry. Retry again. ");
						check = false;
						break;
					}
				} while (!check);
				System.out.println("Guest identity is successfully updated");
				break;
			case 3:
				System.out.println("Enter credit card number to be updated");
				ccNo = sc.nextLine();
				System.out.println("Credit card number is successfully updated");
				break;
			case 4:
				System.out.println("Enter contact number of guest to be updated");
				contact = sc.nextLine();
				System.out.println("Contact number is successfully updated");
				break;
			case 5:
				System.out.println("Enter address to be updated");
				address = sc.nextLine();
				System.out.println("Address is successfully updated");
				break;
			case 6:
				System.out.println("exiting");
				choice = 7;
				break;
			}
		} while (choice > 0 && choice < 7);
		System.out.println("New Guest Info: ");
		print();
	}

	public void print() {
		System.out.println("             Guest Information");
		System.out.println("==============================================");
		System.out.println("Guest ID: " + guest_ID);
		System.out.println("----------------------------------------------");
		System.out.println("Name: " + name);
		System.out.println("----------------------------------------------");
		System.out.println("Gender: " + gender);
		System.out.println("----------------------------------------------");
		System.out.println("Identity: " + identity);
		System.out.println("----------------------------------------------");
		System.out.println("Nationality: " + nationality);
		System.out.println("----------------------------------------------");
		System.out.println("Country of Residence: " + country);
		System.out.println("----------------------------------------------");
		System.out.println("Phone:  " + contact);
		System.out.println("----------------------------------------------");
		System.out.println("Credit Card Number:" + ccNo);
		System.out.println("----------------------------------------------");
		System.out.println("Address: " + address);
		System.out.println("==============================================");
	}

	public static int getTotalGuests() {
		return totalGuest;
	}

	public String getName() {
		return name;
	}

	public String getCredit() {
		return ccNo;
	}

	public int getGuestID() {
		return guest_ID;
	}

	public String getIdentity() {
		return identity;
	}

	public boolean getEmpty() {
		return empty;
	}

	public String toString() {
		return "guestID=" + this.guest_ID + "\nname=" + this.name + "\nccNo=" + this.ccNo + "\naddress=" + this.address
				+ "\ncountry=" + this.country + "\nnationality=" + this.nationality + "\ngender=" + this.gender
				+ "\nidentity=" + this.identity + "\ncontact=" + this.contact + "\nnumChildren=" + this.numChildren
				+ "\nnumAdults=" + this.numAdults + "\nmax_ID=" + this.max_ID + "\ntotalGuest=" + this.totalGuest
				+ "\ncheck=" + this.check + "\nempty=" + this.empty;
	}
}