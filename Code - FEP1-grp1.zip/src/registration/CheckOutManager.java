package registration;
import registration.Guest;
import registration.GuestDB;
import registration.Room;
import registration.roomMnger;
import registration.Check_in;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import java.math.RoundingMode;
import java.text.DecimalFormat;


public class CheckOutManager {
    GuestDB gList = new GuestDB();
    roomMnger room_manager = new roomMnger();
    //ArrayList<roomServiceOrder> orderList = new ArrayList<roomServiceOrder>();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd mm yyyy");
    private final float TAX = 0.07f % 2, DISCOUNT = 0.2f % 2, SERVICE_CHARGE = 0.1f % 2;
    double discountAmount = 0, serviceCharge, tax, subtotal, overallSubtotal, totalBill = 0;
    Scanner sc = new Scanner(System.in);
    private Object ArrayList;
    
    private static DecimalFormat df2 = new DecimalFormat("#.##");


    public void checkOut(Check_in checkIn, Guest guest, Room room, int totalOrder,ArrayList<roomServiceOrder> target_order) throws ParseException {
        System.out.println("Guest Check Out successfully.");
        int checkOutDate = test.getDate();
        int checkInDate = checkIn.getCheckInDate();
        double rate=room.getRate(true);
        double roomBill = calculateRoomBill(checkInDate, checkOutDate, rate); // retrieve rate from room class.
        int guest_ID = guest.getGuestID();
        double serviceBill = calculateServiceBill(guest_ID, totalOrder,target_order);
        //roomServiceBill method returns double
        subtotal = roomBill + serviceBill;
        System.out.println("Apply for Discount?");
        System.out.println("Press 1 for Yes, 2 for No.");
        int input = sc.nextInt();
        switch (input) {
            case 1:
                discountAmount = subtotal * DISCOUNT;
                overallSubtotal = subtotal - discountAmount;
                serviceCharge = overallSubtotal * SERVICE_CHARGE;
                tax = (overallSubtotal + serviceCharge) * TAX;
                totalBill = tax + serviceCharge + overallSubtotal;
                System.out.println("Room Bill: $" + df2.format(roomBill));
                System.out.println("Order Bill: $" + df2.format(serviceBill));
                System.out.println("Subtotal Bill: $" + df2.format(subtotal));
                System.out.println("Discount amount: $" + df2.format(discountAmount));
                System.out.println("Service Charge: $" + df2.format(serviceCharge));
                System.out.println("Tax: $" + df2.format(tax));
                System.out.println("Total Bill: $" + df2.format(totalBill));
                break;
            case 2:
                serviceCharge = subtotal * SERVICE_CHARGE;
                tax = (subtotal + serviceCharge) * TAX;
                totalBill = tax + serviceCharge + subtotal;
                System.out.println("Room Bill: $" + df2.format(roomBill));
                System.out.println("Order Bill: $" + df2.format(serviceBill));
                System.out.println("Subtotal Bill: $" + df2.format(subtotal));
                System.out.println("Service Charge: $" + df2.format(serviceCharge));
                System.out.println("Tax: $" + df2.format(tax));
                System.out.println("Total Bill: $" + df2.format(totalBill));
                break;
            default:
                System.out.print("Invalid entry");
        }
        System.out.println("How would you like to pay? 1.CreditCard 2. Cash");
        int payType = sc.nextInt();

        if (payType == 1) {
            System.out.println("Your credit card number: " + guest.getCredit());
            System.out.println("Payment successful. We hope to see you again");
        }
        if (payType == 2) {
            System.out.println(totalBill);
            System.out.println("Enter cash amount.");
            double cash = sc.nextDouble();
            double change = 0;

            if (cash>totalBill) {
                change = cash - totalBill;
                System.out.println("Guest receives $" + df2.format(change)+"of change");
                System.out.println("Payment Successful. We hope to see you again!");
            } else if (df2.format(cash).equals(df2.format(totalBill)))
                System.out.println("Payment Successful. We hope to see you again!"); // assumed payment always go
                // through as listed in the
                // assignment.
            else {
                double debt = totalBill - cash;
                do {
                    System.out.println("Cash not sufficient. You owe a total of $" + debt);
                    System.out.println("Enter amount: ");
                    cash = sc.nextDouble();
                    if (debt < cash)
                        System.out.println("Payment Successful. We hope to see you again!");
                    else
                        debt -= cash;
                } while (debt > cash);
            }
        }
    }

    public double calculateRoomBill(int check_in, int check_out, double rate) {
        int stayDays = check_out - check_in;
        if(stayDays==0)
            stayDays=1;
        return rate * stayDays;
    }

    public double calculateServiceBill(int guest_id, int totalOrder,ArrayList<roomServiceOrder> target_order){
        double totalRoomServiceBill = 0;
        roomServiceOrder roomSvc;
        Item[] itemList;
        Item item;
        int num_item;
        if (totalOrder == 0)
            totalRoomServiceBill = 0;
        for (int i = 0; i< totalOrder; i++){
            roomSvc = target_order.get(i);
            itemList=roomSvc.getItemList();
            num_item=itemList.length;
            for(int j=0;j<num_item;j++) {
                item=itemList[j];
                if (item==null)
                    break;
                else {
                    double price = item.getPrice();
                    System.out.println("PRICE:"+price);
                    totalRoomServiceBill += item.getPrice();
                }
            }
        }
        return totalRoomServiceBill;
    }

}