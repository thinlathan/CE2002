package registration;

import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Payment {
    Scanner sc = new Scanner(System.in);
    private static PaymentMode paymentMode;
    private long stay_days;
    private int roomRate;
    private int roomServiceBill;
    private final float TAX=0.07f%2,DISCOUNT= 0.2f%2,SERVICE_CHARGE=0.1f%2;
    private double hotelBill;
    private double totalBill;
    private String check_In;
    private String check_Out;
    public enum PaymentMode{
        CASH,
        CREDIT_CARD,
        NULL;
    }
    public double getHotelBill(){
        return hotelBill;
    }
    public double getTotalBill(){
        return totalBill;
    }
    public void setHotelBill(){
        this.hotelBill = hotelBill;
    }
    public void setTotalBill(){
        this.totalBill = totalBill;
    }
    public static PaymentMode getPaymentMode(){
        return paymentMode;
    }
    public static void setPaymentMode(PaymentMode paymentMode){
        Payment.paymentMode = paymentMode;
    }

    public void checkOut(){
        double discountAmount = 0, serviceCharge, tax, subtotal, overallSubtotal;
        totalBill = 0;
        System.out.print("Enter your check-in date: ");
        check_In = sc.nextLine();
        System.out.print("Enter your check-out date");
        check_Out = sc.nextLine();
        double Room_bill = calculateRoomBill(check_In, check_Out);
        System.out.print(Room_bill);
        System.out.println ("Apply for Discount?");
        System.out.println("Press 1 for Yes, 2 for No.");
        int input = sc.nextInt();
        switch(input){
            case 1:
                subtotal = Room_bill + roomServiceBill;
                discountAmount = subtotal*DISCOUNT;
                overallSubtotal = subtotal - discountAmount;
                serviceCharge = overallSubtotal*SERVICE_CHARGE;
                tax = (overallSubtotal + serviceCharge)*TAX;
                totalBill = tax + serviceCharge + overallSubtotal;
                System.out.print(totalBill);
                break;
            case 2:
                subtotal = Room_bill + roomServiceBill;
                serviceCharge = subtotal*SERVICE_CHARGE;
                tax = (subtotal + serviceCharge)*TAX;
                totalBill = tax + serviceCharge + subtotal;
                System.out.print(totalBill);
                break;
            default:
                System.out.print("Invalid entry");
        }
        PaymentMode paymentMode = PaymentMode.NULL;
        System.out.print("Payment Type: Press 1 for Cash, 2 for CreditCard");
        int option = sc.nextInt();
        switch (option){
            case 1:
                paymentMode = PaymentMode.CASH;
                break;
            case 2:
                paymentMode = PaymentMode.CREDIT_CARD;
        }
        System.out.print("Confirm Payment? : (1) Yes (2) No");
        switch(sc.nextInt()){
            case 1:
                System.out.print("Payment successfully completed. Thank you for choosing this hotel and we wish to serve you again.");
                break;
            case 2:
                System.out.print("Payment not completed");
                break;
            default:
                System.out.print("Invalid entry. ");
        }
    }
    public double calculateRoomBill(String check_In, String check_Out){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd mm yyyy");
        try {
            Date date1 = dateFormat.parse(check_In);
            Date date2 = dateFormat.parse(check_Out);
            stay_days = date2.getTime() - date1.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return roomRate * (int) stay_days;
    }

}