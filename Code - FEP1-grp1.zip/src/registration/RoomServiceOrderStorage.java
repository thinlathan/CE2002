package registration;

import java.io.*;
//import java.nio.*;
import java.util.ArrayList;

public class RoomServiceOrderStorage {
	File file;
	int updated_order_no;
	private ArrayList<roomServiceOrder> dummyrsoList = new ArrayList<roomServiceOrder>();

	public RoomServiceOrderStorage() {
		file = new File("RoomServiceOrder.txt");
	}

	public void write(ArrayList<roomServiceOrder> rsoList, int orderNo) {
		roomServiceOrder rso;
		try {
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);

			bw.write("StartingCode=" + String.valueOf(orderNo));

			for (int i = 0; i < rsoList.size(); i++) {
				bw.newLine();
				rso = rsoList.get(i);
				bw.write(rso.toString());
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<roomServiceOrder> read() {
		ArrayList<roomServiceOrder> dummyrsoList = new ArrayList<roomServiceOrder>();
		Item[] itemList = new Item[20];
		int guestID;
		int orderNo;
		int dateOfOrder;
		int timeOfOrder;
		String name;
		String description;
		double price;
		String remarks;
		String Status;
		double RoomServiceFee;

		if (file.length() != 0) {
			try {
				FileReader fr = new FileReader(file.getAbsoluteFile());
				BufferedReader br = new BufferedReader(fr);

				String line = br.readLine();
				updated_order_no = Integer.parseInt(line.substring(13)); // line 1
				while (line != null) {
					int i = 0;
					while (i < updated_order_no) {
						i++;
						line = br.readLine();// first order
						guestID = Integer.parseInt(line.substring(9));

						line = br.readLine();
						orderNo = Integer.parseInt(line.substring(9));

						line = br.readLine();
						dateOfOrder = Integer.parseInt(line.substring(13));

						line = br.readLine();
						timeOfOrder = Integer.parseInt(line.substring(13));

						int count = 0;
						line = br.readLine();
						while (line.charAt(0) != 'r') {
							name = line.substring(6);

							line = br.readLine();
							description = line.substring(13);

							line = br.readLine();
							price = Double.parseDouble(line.substring(7));

							Item item = new Item(name, description, price);
							itemList[count] = item;
							count++;
							line = br.readLine();
						}
						remarks = line.substring(9);

						line = br.readLine();
						Status = line.substring(8);

						line = br.readLine();
						RoomServiceFee = Double.parseDouble(line.substring(16));

						dummyrsoList.add(new roomServiceOrder(guestID, orderNo, dateOfOrder, timeOfOrder, itemList,
								remarks, Status, RoomServiceFee));
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		roomServiceOrder dummyrso = dummyrsoList.get(0);
		System.out.println("HERE=\n" + dummyrso.toString());
		return dummyrsoList;
	}

	public int getOrderNo() {
		return updated_order_no;
	}
}