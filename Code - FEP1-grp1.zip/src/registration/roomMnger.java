package registration;

public class roomMnger {
	public static String[] singleRoomNo = new String[] { "01-01", "01-03", "01-05", "02-02", "02-04", "02-06", "03-01",
			"03-03", "03-05", "03-07", "04-02", "04-06", "04-07", "05-01", "05-03" };
	public static String[] doubleRoomNo = new String[] { "01-02", "01-04", "01-06", "01-07", "02-01", "02-03", "02-05",
			"02-07", "03-02", "03-04", "03-06", "04-01", "04-03", "04-04", "04-05", "05-02", "05-04", "05-05", "05-06",
			"05-07", "06-01", "06-02", "06-03", "06-04", "06-05" };
	public static String[] deluxeRoomNo = new String[] { "06-06", "06-07", "07-01", "07-02", "07-03" };
	public static String[] VIPSuiteNo = new String[] { "07-04", "07-05", "07-06" };

	private int numEmptyRoom;
	private Room[] singleRoom = new Room[15];
	private int numEmptySingleRoom;
	private Room[] doubleRoom = new Room[25];
	private int numEmptyDoubleRoom;
	private Room[] deluxeRoom = new Room[5];
	private int numEmptyDeluxeRoom;
	private Room[] VIPSuite = new Room[3];
	private int numEmptyVIPSuite;

	final int totalRoom = 48;
	final int totSingleRoom = 15;
	final int totDoubleRoom = 25;
	final int totDeluxeRoom = 5;
	final int totVIPSuite = 3;

	// CONSTRUCTOR
	public roomMnger() {
		numEmptyRoom = 48;
		for (int i = 0; i < totDoubleRoom; i++) {
			doubleRoom[i] = new Room("Double", "Double", 80.00, 95.00, false, "null", false, false, false);
			doubleRoom[i].setRoomNumberDouble(i);
		}
		for (int i = 0; i < totSingleRoom; i++) {
			singleRoom[i] = new Room("Single", "Single", 70.00, 85.00, false, "null", false, false, false);
			singleRoom[i].setRoomNumberSingle(i);
		}
		for (int i = 0; i < totDeluxeRoom; i++) {
			deluxeRoom[i] = new Room("Deluxe", "Double", 100.00, 140.00, false, "null", false, false, false);
			deluxeRoom[i].setRoomNumberDeluxe(i);
		}
		for (int i = 0; i < totVIPSuite; i++) {
			VIPSuite[i] = new Room("VIP", "Double", 190.00, 250.00, false, "null", false, false, false);
			VIPSuite[i].setRoomNumberVIP(i);
		}
	}

	public roomMnger(int numEmptyRoom, Room[] singleRoom, int numEmptySingleRoom, Room[] doubleRoom,
			int numEmptyDoubleRoom, Room[] deluxeRoom, int numEmptyDeluxeRoom, Room[] VIPSuite, int numEmptyVIPSuite) {
		this.numEmptyRoom = numEmptyRoom;
		this.singleRoom = singleRoom;
		this.numEmptySingleRoom = numEmptySingleRoom;
		this.doubleRoom = doubleRoom;
		this.numEmptyDoubleRoom = numEmptyDoubleRoom;
		this.deluxeRoom=deluxeRoom;
		this.numEmptyDeluxeRoom=numEmptyDeluxeRoom;
		this.VIPSuite=VIPSuite;
		this.numEmptyVIPSuite=numEmptyVIPSuite;
	}

	// METHODS

	// Get room type and name input
	public boolean checkRoomType(String rType, String rNumber) {
		if (rType.equals("Single")) {
			for (int j = 0; j < singleRoomNo.length; j++)
				if (rNumber.equals(singleRoomNo[j]))
					return true;
		} else if (rType.equals("Double")) {
			for (int j = 0; j < doubleRoomNo.length; j++)
				if (rNumber.equals(doubleRoomNo[j]))
					return true;
		} else if (rType.equals("Deluxe")) {
			for (int j = 0; j < deluxeRoomNo.length; j++)
				if (rNumber.equals(deluxeRoomNo[j]))
					return true;
		} else if (rType.equals("VIP")) {
			for (int j = 0; j < VIPSuiteNo.length; j++)
				if (rNumber.equals(VIPSuiteNo[j]))
					return true;
		}
		System.out.println("No such room exists. Try again!");
		return false;
	}

	public int getnumEmptySingleRoom() {
		return this.numEmptySingleRoom;
	}

	public int getnumEmptyDoubleRoom() {
		return this.numEmptyDoubleRoom;
	}

	public int getnumEmptyDeluxeRoom() {
		return this.numEmptyDeluxeRoom;
	}

	public int getnumEmptyVIPSuite() {
		return this.numEmptyVIPSuite;
	}

	// Get room
	public Room getRoom(String RoomTyp, String roomNum) {
		String dummie;
		if ((RoomTyp.equals("Single") == true)) {
			for (int i = 0; i < singleRoomNo.length; i++) {
				dummie = singleRoom[i].getRoomNumber();
				if (roomNum.equals(dummie) == true)
					return singleRoom[i];
			}
		}
		if ((RoomTyp.equals("Double") == true)) {
			for (int i = 0; i < doubleRoomNo.length; i++) {
				dummie = doubleRoom[i].getRoomNumber();
				if (roomNum.equals(dummie) == true)
					return doubleRoom[i];
			}
		}
		if ((RoomTyp.equals("Deluxe") == true)) {
			for (int i = 0; i < deluxeRoomNo.length; i++) {
				dummie = deluxeRoom[i].getRoomNumber();
				if (roomNum.equals(dummie) == true)
					return deluxeRoom[i];
			}
		}

		for (int i = 0; i < VIPSuiteNo.length; i++) {
			dummie = VIPSuite[i].getRoomNumber();
			if (roomNum.equals(dummie) == true)
				return VIPSuite[i];
		}
		System.out.println("getRoomFails");
		return VIPSuite[2];
	}

	// #########ASSIGN ROOM###########
	public void assign(int guestID, String roomStatus, String room_num, String roomType) {
		String rNumber;
		if (roomType.equals("Single") == true) {
			for (int i = 0; i < totSingleRoom; i++) {
				rNumber = this.singleRoom[i].getRoomNumber();
				if (rNumber.equals(room_num)) {
					this.singleRoom[i].assignRoom(guestID, roomStatus);
					break;
				}
			}
		} else if (roomType.equals("Double") == true) {
			for (int i = 0; i < totDoubleRoom; i++) {
				rNumber = this.doubleRoom[i].getRoomNumber();
				if (rNumber.equals(room_num)) {
					this.doubleRoom[i].assignRoom(guestID, roomStatus);
				}
			}
		} else if (roomType.equals("Deluxe") == true) {
			for (int i = 0; i < totDeluxeRoom; i++) {
				rNumber = this.deluxeRoom[i].getRoomNumber();
				if (rNumber.equals(room_num)) {
					this.deluxeRoom[i].assignRoom(guestID, roomStatus);
				}
			}
		} else if (roomType.equals("VIP") == true) {
			for (int i = 0; i < totVIPSuite; i++) {
				rNumber = this.VIPSuite[i].getRoomNumber();
				if (rNumber.equals(room_num)) {
					this.VIPSuite[i].assignRoom(guestID, roomStatus);
				}
			}
		}
	}

	// #########UNASSIGN ROOM##############
	public void unAssign(String room_num, String roomType) {
		String rNumber;
		if (roomType.equals("Single") == true) {
			for (int i = 0; i < totSingleRoom; i++) {
				rNumber = this.singleRoom[i].getRoomNumber();
				if (rNumber.equals(room_num)) {
					this.singleRoom[i].unAssignRoom();
				}
			}
			this.numEmptySingleRoom++;
		} else if (roomType.equals("Double") == true) {
			for (int i = 0; i < totDoubleRoom; i++) {
				rNumber = this.doubleRoom[i].getRoomNumber();
				if (rNumber.equals(room_num)) {
					this.doubleRoom[i].unAssignRoom();
				}
			}
			this.numEmptyDoubleRoom++;
		} else if (roomType.equals("Deluxe") == true) {
			for (int i = 0; i < totDeluxeRoom; i++) {
				rNumber = this.deluxeRoom[i].getRoomNumber();
				if (rNumber.equals(room_num)) {
					this.deluxeRoom[i].unAssignRoom();
				}
			}
			this.numEmptyDeluxeRoom++;
		} else if (roomType.equals("VIP") == true) {
			for (int i = 0; i < totVIPSuite; i++) {
				rNumber = this.VIPSuite[i].getRoomNumber();
				if (rNumber.equals(room_num)) {
					this.VIPSuite[i].unAssignRoom();
				}
			}
			this.numEmptyVIPSuite++;
		}
		this.numEmptyRoom++;
	}

	// Vacant room count
	public int countSingleEmptyRoom() {
		int count = 0;
		for (int i = 0; i < singleRoom.length; i++) {
			if (this.singleRoom[i].getRoomStatus().equals("Vacant")) {
				count++;
			}
		}
		return count;
	}

	public int countDoubleEmptyRoom() {
		int count = 0;
		for (int i = 0; i < doubleRoom.length; i++) {
			if (this.doubleRoom[i].getRoomStatus().equals("Vacant")) {
				count++;
			}
		}
		return count;
	}

	public int countDeluxeEmptyRoom() {
		int count = 0;
		for (int i = 0; i < deluxeRoom.length; i++) {
			if (this.deluxeRoom[i].getRoomStatus().equals("Vacant")) {
				count++;
			}
		}
		return count;
	}

	public int countVIPEmptyRoom() {
		int count = 0;
		for (int i = 0; i < VIPSuite.length; i++) {
			if (this.VIPSuite[i].getRoomStatus().equals("Vacant")) {
				count++;
			}
		}
		return count;
	}

	// #######PRINT REPORT###############
	// Occupancy rate
	public void printRoomTypeOccupancyReport() {
		System.out.println("Single : " + "Number : " + countSingleEmptyRoom() + " out of " + this.totSingleRoom);
		System.out.print("            Rooms: ");
		for (int i = 0; i < totSingleRoom; i++) {
			if (this.singleRoom[i].occupancy() == true) {
				System.out.print(this.singleRoom[i].getRoomNumber() + ", ");
			}
		}
		System.out.println();
		System.out.println("Double : " + "Number : " + countDoubleEmptyRoom() + " out of " + this.totDoubleRoom);
		System.out.print("            Rooms: ");
		for (int i = 0; i < totDoubleRoom; i++) {
			if (this.doubleRoom[i].occupancy() == true) {
				System.out.print(this.doubleRoom[i].getRoomNumber() + ", ");
			}
		}
		System.out.println();
		System.out.println("Deluxe : " + "Number : " + countDeluxeEmptyRoom() + " out of " + this.totDeluxeRoom);
		System.out.print("            Rooms: ");
		for (int i = 0; i < totDeluxeRoom; i++) {
			if (this.deluxeRoom[i].occupancy() == true) {
				System.out.print(this.deluxeRoom[i].getRoomNumber() + ", ");
			}
		}
		System.out.println();
		System.out.println("VIP Suite: Number : " + countVIPEmptyRoom() + " out of " + this.totVIPSuite);
		System.out.print("            Rooms: ");
		for (int i = 0; i < totVIPSuite; i++) {
			if (this.VIPSuite[i].occupancy() == true) {
				System.out.print(this.VIPSuite[i].getRoomNumber() + ", ");
			}
		}
		System.out.println();
	}

	// Status report
	public void printStatusReport() {
		//// vacant
		System.out.println("Vacant  :");
		System.out.print("         Rooms: ");
		for (int i = 0; i < totSingleRoom; i++) {
			if (this.singleRoom[i].getRoomStatus().equals("Vacant")) {
				System.out.print(this.singleRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totDoubleRoom; i++) {
			if (this.doubleRoom[i].getRoomStatus().equals("Vacant")) {
				System.out.print(this.doubleRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totDeluxeRoom; i++) {
			if (this.deluxeRoom[i].getRoomStatus().equals("Vacant")) {
				System.out.print(this.deluxeRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totVIPSuite; i++) {
			if (this.VIPSuite[i].getRoomStatus().equals("Vacant")) {
				System.out.print(this.VIPSuite[i].getRoomNumber() + ", ");
			}
		}
		///// Occupied
		System.out.println();
		System.out.println("Occupied  :");
		System.out.print("         Rooms: ");
		for (int i = 0; i < totSingleRoom; i++) {
			if (this.singleRoom[i].getRoomStatus().equals("Occupied")) {
				System.out.print(this.singleRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totDoubleRoom; i++) {
			if (this.doubleRoom[i].getRoomStatus().equals("Occupied")) {
				System.out.print(this.doubleRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totDeluxeRoom; i++) {
			if (this.deluxeRoom[i].getRoomStatus().equals("Occupied")) {
				System.out.print(this.deluxeRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totVIPSuite; i++) {
			if (this.VIPSuite[i].getRoomStatus().equals("Occupied")) {
				System.out.print(this.VIPSuite[i].getRoomNumber() + ", ");
			}
		}
		/// Reserved
		System.out.println();
		System.out.println("Reserved  :");
		System.out.print("         Rooms: ");
		for (int i = 0; i < totSingleRoom; i++) {
			if (this.singleRoom[i].getRoomStatus().equals("Reserved")) {
				System.out.print(this.singleRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totDoubleRoom; i++) {
			if (this.doubleRoom[i].getRoomStatus().equals("Reserved")) {
				System.out.print(this.doubleRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totDeluxeRoom; i++) {
			if (this.deluxeRoom[i].getRoomStatus().equals("Reserved")) {
				System.out.print(this.deluxeRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totVIPSuite; i++) {
			if (this.VIPSuite[i].getRoomStatus().equals("Reserved")) {
				System.out.print(this.VIPSuite[i].getRoomNumber() + ", ");
			}
		}
		/// Under Maintenance
		System.out.println();
		System.out.println("Under Maintenance  :");
		System.out.print("         Rooms: ");
		for (int i = 0; i < totSingleRoom; i++) {
			if (this.singleRoom[i].getRoomStatus().equals("Under Maintenance")) {
				System.out.print(this.singleRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totDoubleRoom; i++) {
			if (this.doubleRoom[i].getRoomStatus().equals("Under Maintenance")) {
				System.out.print(this.doubleRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totDeluxeRoom; i++) {
			if (this.deluxeRoom[i].getRoomStatus().equals("Under Maintenance")) {
				System.out.print(this.deluxeRoom[i].getRoomNumber() + ", ");
			}
		}
		for (int i = 0; i < totVIPSuite; i++) {
			if (this.VIPSuite[i].getRoomStatus().equals("Under Maintenance")) {
				System.out.print(this.VIPSuite[i].getRoomNumber() + ", ");
			}
		}
		System.out.print("\n");
	}

	public String toString() {
		int i;
		String StringMain = singleRoom[0].toString();
		String StringTemp;
		for (i = 1; i < 15; i++) {
			StringTemp = singleRoom[i].toString();
			StringMain = StringMain.concat("\n");
			StringMain = StringMain.concat(StringTemp);
		}
		StringMain = StringMain.concat("\nnumEmptySingleRoom:" + numEmptySingleRoom);
		for (i = 0; i < 25; i++) {
			StringTemp = doubleRoom[i].toString();
			StringMain = StringMain.concat("\n");
			StringMain = StringMain.concat(StringTemp);
		}
		StringMain = StringMain.concat("\nnumEmptyDoubleRoom:" + numEmptyDoubleRoom);
		for (i = 0; i < 5; i++) {
			StringTemp = deluxeRoom[i].toString();
			StringMain = StringMain.concat("\n");
			StringMain = StringMain.concat(StringTemp);
		}
		StringMain = StringMain.concat("\nnumEmptyDeluxeRoom:" + numEmptyDeluxeRoom);
		for (i = 0; i < 3; i++) {
			StringTemp = VIPSuite[i].toString();
			StringMain = StringMain.concat("\n");
			StringMain = StringMain.concat(StringTemp);
		}
		StringMain = StringMain.concat("\nnumEmptyVIPRoom:" + numEmptyVIPSuite);

		return "numEmptyRoom:" + numEmptyRoom + "\n" + StringMain;
	}
}