package registration;

import java.io.*;
//import java.nio.*;

public class MenuStorage {
	File file;

	public MenuStorage() {
		file = new File("Menu.txt");
	}

	public void write(Menu menu) {
		Item item;
		String name;
		try {
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);

			for (int i = 0; i < menu.getMenuSize(); i++) {
				bw.newLine();
				item = menu.getOneItem(i);
				bw.write(item.toString());
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Menu read() {
		Menu dummyMenu = new Menu();
		int orderno = 0;
		String name;
		String description;
		double price;
		if (file.length() != 0) {
			try {
				FileReader fr = new FileReader(file.getAbsoluteFile());
				BufferedReader br = new BufferedReader(fr);

				String line = br.readLine();
				while (line != null) {
					line = br.readLine();
					name = line.substring(6);
					// System.out.println(name);

					line = br.readLine();
					description = line.substring(13);
					// System.out.println(description);

					line = br.readLine();
					price = Double.parseDouble(line.substring(7));
					// System.out.println(price);

					dummyMenu.createItem(name, description, price);
					line = br.readLine();
					orderno++;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return dummyMenu;
	}
}