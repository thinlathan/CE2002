package registration;

import java.util.Scanner;

public class Check_in {
	Scanner sc = new Scanner(System.in);
	private int checkInCode;
	private int dateOfCheckIn;
	private int timeOfCheckIn;
	public String roomNumber;
	public int guestID;
	public String roomType;

	public Check_in() {

	}

	public Check_in(int cCode, int cDate, int cTime, int gID, String rNumber, String rType) {
		checkInCode = cCode;
		dateOfCheckIn = cDate;
		timeOfCheckIn = cTime;
		guestID = gID;
		roomNumber = rNumber;
		roomType = rType;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void printReceipt() {
		System.out.println("GuestID: " + guestID);
		System.out.println("Date: " + dateOfCheckIn);
		System.out.println("Time: " + timeOfCheckIn);
		System.out.println("Room Number: " + roomNumber);
	}

	public int getGuestID() {
		return guestID;
	}

	public String getRoomType() {
		return roomType;
	}

	public int getCheckInDate() {
		return dateOfCheckIn;
	}

	public String toString() {
		return "cCode=" + checkInCode + "\ncDate=" + dateOfCheckIn + "\ncTime=" + timeOfCheckIn + "\ngID=" + guestID
				+ "\nrNUmber=" + roomNumber + "\nrType=" + roomType;

	}
}
