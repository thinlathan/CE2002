package registration;

import java.util.Scanner;

public class Reservation extends Check_in {
	Scanner sc = new Scanner(System.in);
	private int reservationCode;
	private String reservationStatus; // 0=Confirmed, 1=Checked In, 2=Expired,
	private int expectedDateOfCheckIn;
	private int expectedTimeOfCheckIn;

	public Reservation(int rCode, String rStatus, int eDate, int eTime, int gID, String rNumber, String rType) {
		reservationCode = rCode;
		reservationStatus = rStatus;
		expectedDateOfCheckIn = eDate;
		expectedTimeOfCheckIn = eTime;
		guestID = gID;
		roomNumber = rNumber;
		roomType = rType;
	}

	public Reservation(int rCode, int guestId, String roomNo, String roomTyp) {
		reservationCode = rCode;
		reservationStatus = "Confirmed";
		roomNumber = roomNo;
		guestID = guestId;
		roomType = roomTyp;
		System.out.println("Enter your expected date of check in (YYYYMMDD)");
		expectedDateOfCheckIn = sc.nextInt();
		System.out.println("Enter your expected time of check in (HHMMSS)");
		expectedTimeOfCheckIn = sc.nextInt();
		checkExpiry();
		printReservationAcknowledgementReceipt();
	}

	public void checkExpiry() {
		if (reservationStatus.contentEquals("Confirmed") == true) {
			int cDate = test.getDate();
			int cTime = test.getTime();
			if (cDate - expectedDateOfCheckIn > 0)
				reservationStatus = "Expired";
			else if (cDate - expectedDateOfCheckIn == 0)
				if (cTime - expectedTimeOfCheckIn > 10000)
					reservationStatus = "Expired";
		}
	}

	public void printReservationAcknowledgementReceipt() {
		System.out.println("==============================================");
		System.out.println(" Here is your Reservation Acknowledge Receipt ");
		System.out.println("==============================================");
		System.out.println("Your Reservation Code is: " + reservationCode);
		System.out.println("Your Reservation Status is: " + reservationStatus);
		System.out.println("Expected Date of Check In: " + expectedDateOfCheckIn);
		System.out.println("Expected Time of Check In: " + expectedTimeOfCheckIn);
		System.out.println("Your room number is: " + roomNumber);
	}

	public void updateReservation() {
		int choice;
		do {
			System.out.println("Enter the option you would like to change");
			System.out.println("1. Expected date of check in (YYYYMMDD)");
			System.out.println("2. Expected time of chceck in (HHMMSS)");
			System.out.println("3. Quit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter your expected date of check in (YYYYMMDD)");
				expectedDateOfCheckIn = sc.nextInt();
				System.out.println("Update complete");
				break;
			case 2:
				System.out.println("Enter your expected time of check in (HHMMSS)");
				expectedTimeOfCheckIn = sc.nextInt();
				System.out.println("Update complete");
				break;
			case 3:
				break;
			default:
				System.out.println("Wrong input!");
				break;
			}
		} while (choice != 3);
	}

	public int checkReservationStatus() {
		if (reservationStatus.equals("Confirmed"))
			return 0;
		if (reservationStatus.equals("Checked_In"))
			return 1;
		if (reservationStatus.equals("Expired"))
			return 2;
		System.out.println("Something wrong");
		return 999;
	}

	public String getReservationStatus() {
		return reservationStatus;
	}

	public void checkInReservation() {
		reservationStatus = "Checked_In";
	}

	public String getRoomType() {
		return roomType;
	}

	public String toString() {
		return "rCode=" + reservationCode + "\nrStatus=" + reservationStatus + "\neDate=" + expectedDateOfCheckIn
				+ "\neTime=" + expectedTimeOfCheckIn + "\ngID=" + guestID + "\nrNUmber=" + roomNumber + "\nrType="
				+ roomType;
	}
}
