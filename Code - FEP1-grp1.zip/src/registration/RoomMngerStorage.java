package registration;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class RoomMngerStorage {

	File file;

	public RoomMngerStorage() {
		file = new File("Room.txt");
	}

	public void write(roomMnger rManager) {
		try {
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(rManager.toString());
			bw.newLine();
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public roomMnger read() {
		roomMnger dummyRMnger;
		int numEmptyRoom=0;
		Room[] singleRoom = new Room[15];
		int numEmptySingleRoom=0;
		Room[] doubleRoom = new Room[25];
		int numEmptyDoubleRoom=0;
		Room[] deluxeRoom = new Room[5];
		int numEmptyDeluxeRoom=0;
		Room[] VIPSuite = new Room[3];
		int numEmptyVIPSuite=0;

		int guestID;
		String roomNumber;
		String rType;
		String roomStatus;
		String bedType;
		double rateNormal;
		double rateWeekend;
		boolean hasWIFI;
		String facing;
		boolean smoking;
		boolean hasBalcony;
		boolean hasPool;
		boolean isEmpty;
		// INteger: Integer.parseInt(line.substring());
		// String: line.substring();
		// Double: Double.parseDouble(line.substring());

		try {
			FileReader fr = new FileReader(file.getAbsoluteFile());
			BufferedReader br = new BufferedReader(fr);

			String line = br.readLine();
			numEmptyRoom = Integer.parseInt(line.substring(13)); // read current rCode
			if (file.length() != 0) {

				for (int i = 0; i < 15; i++) {
					line = br.readLine();
					guestID = Integer.parseInt(line.substring(8));
					line = br.readLine();
					roomNumber = line.substring(11);
					line = br.readLine();
					rType = line.substring(9);
					line = br.readLine();
					roomStatus = line.substring(11);
					line = br.readLine();
					bedType = line.substring(8);
					line = br.readLine();
					rateNormal = Double.parseDouble(line.substring(11));
					line = br.readLine();
					rateWeekend = Double.parseDouble(line.substring(12));
					line = br.readLine();
					hasWIFI = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					facing = line.substring(7);
					line = br.readLine();
					smoking = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					hasBalcony = Boolean.parseBoolean(line.substring(11));
					line = br.readLine();
					hasPool = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					isEmpty = Boolean.parseBoolean(line.substring(8));
					singleRoom[i] = new Room(guestID, roomNumber, rType, roomStatus, bedType, rateNormal, rateWeekend,
							hasWIFI, facing, smoking, hasBalcony, hasPool, isEmpty);
				}
				line = br.readLine();
				numEmptySingleRoom = Integer.parseInt(line.substring(19));
				
				for (int i = 0; i < 25; i++) {
					line = br.readLine();
					guestID = Integer.parseInt(line.substring(8));
					line = br.readLine();
					roomNumber = line.substring(11);
					line = br.readLine();
					rType = line.substring(9);
					line = br.readLine();
					roomStatus = line.substring(11);
					line = br.readLine();
					bedType = line.substring(8);
					line = br.readLine();
					rateNormal = Double.parseDouble(line.substring(11));
					line = br.readLine();
					rateWeekend = Double.parseDouble(line.substring(12));
					line = br.readLine();
					hasWIFI = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					facing = line.substring(7);
					line = br.readLine();
					smoking = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					hasBalcony = Boolean.parseBoolean(line.substring(11));
					line = br.readLine();
					hasPool = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					isEmpty = Boolean.parseBoolean(line.substring(8));
					doubleRoom[i] = new Room(guestID, roomNumber, rType, roomStatus, bedType, rateNormal, rateWeekend,
							hasWIFI, facing, smoking, hasBalcony, hasPool, isEmpty);
				}
				
				line = br.readLine();
				numEmptyDoubleRoom = Integer.parseInt(line.substring(19));
				
				for (int i = 0; i < 5; i++) {
					line = br.readLine();
					guestID = Integer.parseInt(line.substring(8));
					line = br.readLine();
					roomNumber = line.substring(11);
					line = br.readLine();
					rType = line.substring(9);
					line = br.readLine();
					roomStatus = line.substring(11);
					line = br.readLine();
					bedType = line.substring(8);
					line = br.readLine();
					rateNormal = Double.parseDouble(line.substring(11));
					line = br.readLine();
					rateWeekend = Double.parseDouble(line.substring(12));
					line = br.readLine();
					hasWIFI = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					facing = line.substring(7);
					line = br.readLine();
					smoking = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					hasBalcony = Boolean.parseBoolean(line.substring(11));
					line = br.readLine();
					hasPool = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					isEmpty = Boolean.parseBoolean(line.substring(8));
					deluxeRoom[i] = new Room(guestID, roomNumber, rType, roomStatus, bedType, rateNormal, rateWeekend,
							hasWIFI, facing, smoking, hasBalcony, hasPool, isEmpty);
				}
				
				line = br.readLine();
				numEmptyDeluxeRoom = Integer.parseInt(line.substring(19));
				
				for (int i = 0; i < 3; i++) {
					line = br.readLine();
					guestID = Integer.parseInt(line.substring(8));
					line = br.readLine();
					roomNumber = line.substring(11);
					line = br.readLine();
					rType = line.substring(9);
					line = br.readLine();
					roomStatus = line.substring(11);
					line = br.readLine();
					bedType = line.substring(8);
					line = br.readLine();
					rateNormal = Double.parseDouble(line.substring(11));
					line = br.readLine();
					rateWeekend = Double.parseDouble(line.substring(12));
					line = br.readLine();
					hasWIFI = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					facing = line.substring(7);
					line = br.readLine();
					smoking = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					hasBalcony = Boolean.parseBoolean(line.substring(11));
					line = br.readLine();
					hasPool = Boolean.parseBoolean(line.substring(8));
					line = br.readLine();
					isEmpty = Boolean.parseBoolean(line.substring(8));
					VIPSuite[i] = new Room(guestID, roomNumber, rType, roomStatus, bedType, rateNormal, rateWeekend,
							hasWIFI, facing, smoking, hasBalcony, hasPool, isEmpty);
				}
				
				line = br.readLine();
				numEmptyVIPSuite = Integer.parseInt(line.substring(16));

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		dummyRMnger = new roomMnger(numEmptyRoom, singleRoom, numEmptySingleRoom, doubleRoom, numEmptyDoubleRoom,
				deluxeRoom, numEmptyDeluxeRoom, VIPSuite, numEmptyVIPSuite);
		return dummyRMnger;
	}

}
