package registration;
import java.util.Scanner;

public class GuestDB {
    private Guest[] guestList;
    private static int count = 0;
    Scanner sc = new Scanner(System.in);
    public GuestDB(){
        Guest[] blankList = new Guest[1000];
        for(int i = 0; i<1000; i++)
            blankList[i] = new Guest();
        guestList = blankList;
    }

    public void createGuest(){
        count++;
        guestList[count - 1] = new Guest(true);
    }
    
    public void updateGuest(int guest_ID,String name,String ccNo,String address,String country,String nationality,String gender,String identity,String contact,int numChildren,int numAdults,int max_ID,int totalGuest, Boolean check,Boolean empty){    	
        count++;
        guestList[count - 1] = new Guest(guest_ID,name,ccNo,address,country,nationality,gender,identity,contact,numChildren,numAdults,max_ID,totalGuest,check,empty);

    }
    public static Boolean validate(int guest_ID){
        if ((!(guest_ID > count) & (guest_ID < 1)))
            return true;
        else{
            System.out.println("Guest does not exist in database");
            return false;
        }
    }

    public int getCount(){ return count;}
    public Guest[] getGuestList(){ return guestList;}
    public Guest getGuestElement(int i){ return guestList[i]; }

    public Guest searchGuest(GuestDB gList, String search){
        Guest[] searchList = new Guest[100];
        Guest dummyGuest = new Guest();
        int search_count = -1;

        for (int i = 0; i<gList.getCount(); i++){
            if (gList.getGuestElement(i).getName().contains(search)){
                search_count++;
                searchList[search_count] = gList.getGuestElement(i);
            }
        }

        if (search_count == -1) {
            System.out.println("Target guest not found!!");
            return dummyGuest;
        }
        else if (search_count == 0){
            System.out.println("Search guest found!");
            return searchList[0];
        }
        else{
            System.out.println((search_count +1) + "guests found in database.");
            for (int i = 0; i<=search_count ; i++)
                System.out.println((i+1) + searchList[i].getName()+ "Guest ID: " + searchList[i].getGuestID());

            System.out.println("Enter Guest id: ");
            int id = sc.nextInt();
            for (int i = 0; i<=search_count ; i++){
                if (searchList[i].getGuestID() == id)
                    return searchList[i];
            }
            System.out.println("Search guest does not exist with the following ID");
            return dummyGuest;
        }
    }
}
