package registration;

import java.io.*;
//import java.nio.*;

public class CheckInStorage {
	File file;
	int updatedcCode;

	public CheckInStorage() {
		file = new File("CheckIn.txt");
	}

	public void write(Check_in[] checkIn, int cCode) { // cCode start from 0, update after each entry
		Check_in cIn;
		try {
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
			bw.write("StartingCode="+String.valueOf(cCode));
			
			for (int i = 1; i < cCode; i++) {
				bw.newLine();
				cIn = checkIn[i];
				bw.write(cIn.toString());
				bw.newLine();
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Check_in[] read() {
		Check_in[] dummyCheckIn = new Check_in[100];
		
		int checkInCode;
		int dateOfCheckIn;
		int timeOfCheckIn;
		int guestID;
		String roomNumber;
		String roomType;

		try {
			FileReader fr = new FileReader(file.getAbsoluteFile());
			BufferedReader br = new BufferedReader(fr);
			
			String line = br.readLine();
			updatedcCode=Integer.parseInt(line.substring(13)); //read current cCode
			if(updatedcCode>1) {
				while (line != null) {
					line = br.readLine();
					checkInCode=Integer.parseInt(line.substring(6));
					
					line = br.readLine();
					dateOfCheckIn=Integer.parseInt(line.substring(6));
					
					line = br.readLine();
					timeOfCheckIn=Integer.parseInt(line.substring(6));
					
					line = br.readLine();
					guestID=Integer.parseInt(line.substring(4));
					
					line = br.readLine();
					roomNumber=line.substring(8);
					
					line = br.readLine();
					roomType=line.substring(6);
					
					dummyCheckIn[checkInCode]=new Check_in(checkInCode, dateOfCheckIn, timeOfCheckIn, guestID, roomNumber, roomType);
					line = br.readLine();
				}
			}
		}catch (IOException e) {
			e.printStackTrace();
		}
		return dummyCheckIn;
	}
	
	public int getcCode() {
		return updatedcCode;
	}
}